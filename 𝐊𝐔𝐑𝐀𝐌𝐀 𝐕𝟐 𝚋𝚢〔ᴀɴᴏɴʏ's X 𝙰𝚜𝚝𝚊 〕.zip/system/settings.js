const fs = require('fs')

global.owner = "2349162778761"
global.footer = "dev〽️🔥"
global.idsal = ""
global.image = "https://files.catbox.moe/a7w33q.jpg"
global.linksal = "https://whatsapp.com/channel/0029VawhMjJEVccOP9x8EG1q"
global.autoread = false //true/false

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
